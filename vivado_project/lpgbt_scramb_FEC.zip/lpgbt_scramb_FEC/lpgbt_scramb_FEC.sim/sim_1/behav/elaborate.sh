#!/bin/sh -f
xv_path="/opt/Xilinx/Vivado/2015.1"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 657b2c4cae0c460fa2dc9fcacbc011ef -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip --snapshot tb_enctodec_behav xil_defaultlib.tb_enctodec -log elaborate.log
