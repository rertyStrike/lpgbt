#!/bin/sh -f
xv_path="/opt/Xilinx/Vivado/2015.1"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim tb_enctodec_behav -key {Behavioral:sim_1:Functional:tb_enctodec} -tclbatch tb_enctodec.tcl -view /home/victor/lpgbt_scramb_FEC/tb_enctodec_behav.wcfg -log simulate.log
